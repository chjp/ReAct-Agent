# Agentic 16S Metadata Extraction Pipeline

A config-driven, 6-step pipeline for discovering and extracting metadata from dental caries 16S rRNA sequencing studies. Searches PubMed, screens papers with LLM models, downloads full texts from PMC, extracts BioProject/SRA identifiers, retrieves sample metadata from NCBI, and produces analysis-ready CSV sample sheets.

## Quick Start

```bash
cd fromfresh

# Set up environment
uv venv --python 3.11 .venv
uv pip install -r requirements.txt --python .venv/bin/python
source .venv/bin/activate

# Edit config.yaml with your email and search terms
# Then run steps individually:
python src/step1_paper_discovery.py
```

## Pipeline Steps

| Step | Script | Input | Output | External Calls |
|------|--------|-------|--------|----------------|
| 1 | `step1_paper_discovery.py` | PubMed query | `papers_*.jsonl` | NCBI Entrez |
| 2 | `step2_abstract_screening.py` | papers JSONL | `screening_*.jsonl` | Gemini CLI |
| 3 | `step3_fulltext_download.py` | screening JSONL | `downloads_*.jsonl` + files | PMC OA API |
| 4 | `step4_paper_parsing.py` | downloads JSONL | `parsed_*.jsonl` | Gemini CLI + NCBI |
| 5 | `step5_ncbi_retrieval.py` | parsed JSONL | `ncbi_metadata_*.jsonl` | NCBI Entrez |
| 6 | `step6_sample_sheet.py` | parsed + NCBI JSONL | `sample_sheet_*.csv` | — |

Each step reads the previous step's latest output from `outputs/` automatically.

## Usage

The pipeline is orchestrated interactively by Claude Code + human-in-the-loop. Run each step individually:

```bash
python src/step1_paper_discovery.py       # PubMed search
python src/step2_abstract_screening.py    # AI relevance screening
python src/step3_fulltext_download.py     # PMC full-text download
python src/step4_paper_parsing.py         # Extract BioProject IDs
python src/step5_ncbi_retrieval.py        # Fetch sample metadata
python src/step6_sample_sheet.py          # Generate sample sheet CSV
```

Each step reads the previous step's latest output from `outputs/` automatically. Inspect intermediate results between steps and re-run as needed.

**Per-paper output**: Steps 3-6 also support `process_paper()` for single-paper processing, saving results to `outputs/PMID_{pmid}/` directories.

## Configuration

All settings live in `config.yaml`:

```yaml
entrez:
  email: "your.email@example.com"   # Required by NCBI
  api_key: null                      # Optional — increases rate limit to 10 req/s
  rate_limit: 3

search:
  query: "dental caries microbiome saliva 16S"
  max_results: 50
  min_date: "2015/01/01"

screening:
  inclusion_criteria:
    - "Human saliva samples"
    - "Dental caries as primary focus"
    - "16S rRNA gene sequencing"
    - "Microbiome/community analysis"
    - "Primary research (not review/meta-analysis)"
  exclusion_criteria:
    - "Animal studies"
    - "In vitro studies only"
    - "No sequencing data generated"
```

## Output Naming

All output files follow the convention:

```
{name}_{YYYYMMDD}_{HHMM}_{git_hash}[_beyond].{ext}
```

- `git_hash` — 7-char short hash of the last commit
- `_beyond` — appended when the working tree has uncommitted changes

This creates full provenance: every output can be traced back to the exact code version that produced it.

## Disease Status Inference

Step 6 classifies samples as `healthy`, `caries`, or `unknown` using this priority:

1. BioSample `disease` attribute (direct NCBI metadata)
2. dmfs/DMFS caries indices — `dmfs=0 AND DMFS=0` → healthy, otherwise → caries
3. Sample group mapping from paper metadata (via Gemini extraction)
4. Falls back to `unknown`

## Prerequisites

- **Python 3.11+**
- **Gemini CLI** — used for abstract screening (step 2) and full-text parsing (step 4)
- **NCBI network access** — steps 1, 3, 4, 5 call NCBI E-utilities and PMC APIs

## Testing

```bash
source .venv/bin/activate
python -m pytest tests/ -v
```

65 tests cover all steps with mocked NCBI and Gemini calls. No network access required. `test_per_paper.py` tests the `process_paper()` functions and end-to-end per-paper chaining.

## Project Structure

```
fromfresh/
├── config.yaml                    # Pipeline settings
├── requirements.txt               # Python dependencies
├── src/
│   ├── utils.py                   # Shared utilities (make_paper_dir, RateLimiter, etc.)
│   ├── step1_paper_discovery.py   # PubMed search
│   ├── step2_abstract_screening.py
│   ├── step3_fulltext_download.py # PMC OA download (run + process_paper)
│   ├── step4_paper_parsing.py     # AI + NCBI metadata extraction (run + process_paper)
│   ├── step5_ncbi_retrieval.py    # BioSample/SRA retrieval (run + process_paper)
│   └── step6_sample_sheet.py      # Final CSV generation (run + process_paper)
├── prompts/                       # Gemini prompt templates
├── tests/                         # pytest suite (65 tests)
├── outputs/                       # Timestamped results (gitignored)
│   ├── papers_*.jsonl             # Step 1 batch output
│   ├── screening_*.jsonl          # Step 2 batch output
│   ├── PMID_33051450/             # Per-paper outputs (steps 3-6)
│   │   ├── download.json
│   │   ├── parsed.json
│   │   ├── ncbi_metadata.json
│   │   ├── sample_sheet.csv
│   │   └── downloads/             # Downloaded PMC packages
│   └── sample_sheet_*.csv         # Merged sample sheet
└── downloads/                     # PMC full texts (batch mode, gitignored)
```
