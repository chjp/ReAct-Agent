# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project

Agentic 16S Metadata Extraction Pipeline — a config-driven, 6-step pipeline that discovers dental caries 16S rRNA sequencing studies from PubMed, screens them with AI, downloads full texts, extracts BioProject/SRA identifiers, retrieves sample metadata from NCBI, and produces analysis-ready CSV sample sheets. **Metadata extraction only** — sequencing data download and bioinformatics are out of scope.

## Commands

```bash
# Setup (pip is blocked by corporate proxy — always use uv)
uv venv --python 3.11 .venv
uv pip install -r requirements.txt --python .venv/bin/python
source .venv/bin/activate

# Run individual steps directly
python src/step1_paper_discovery.py
python src/step2_abstract_screening.py
python src/step3_fulltext_download.py
python src/step4_paper_parsing.py
python src/step5_ncbi_retrieval.py
python src/step6_sample_sheet.py

# Tests (65 tests, all mocked, no network needed)
python -m pytest tests/ -v

# Single test file
python -m pytest tests/test_step1.py -v

# Single test
python -m pytest tests/test_step1.py::test_function_name -v

# Format
black src/ tests/
```

## Architecture

**Orchestration**: Claude Code + human-in-the-loop. There is no master orchestrator script — the user and Claude Code decide which steps to run, inspect intermediate outputs, and iterate. Each step can be run independently via `python src/stepN_*.py`.

Each step module exposes two entry points:
- `run(config, prev_output?)` — batch processing (reads/writes JSONL manifests)
- `process_paper(record, config, limiter)` — single-paper processing (reads/writes per-paper JSON in `outputs/PMID_{pmid}/`)

**6 steps, each in `src/`:**

| Step | Module | What it does | External dependency |
|------|--------|-------------|-------------------|
| 1 | `step1_paper_discovery` | PubMed Entrez search → `papers_*.jsonl` | NCBI E-utilities |
| 2 | `step2_abstract_screening` | AI relevance screening → `screening_*.jsonl` | Gemini CLI |
| 3 | `step3_fulltext_download` | PMC OA full-text retrieval → `PMID_*/download.json` | PMC OA API |
| 4 | `step4_paper_parsing` | Extract BioProject IDs (AI + NCBI cross-link) → `PMID_*/parsed.json` | Gemini CLI + NCBI |
| 5 | `step5_ncbi_retrieval` | Fetch BioSample attributes + SRA runs → `PMID_*/ncbi_metadata.json` | NCBI E-utilities |
| 6 | `step6_sample_sheet` | Merge all data → `PMID_*/sample_sheet.csv` + merged `sample_sheet_*.csv` | none |

**Per-paper output directory** (`outputs/PMID_{pmid}/`): Each paper gets its own directory containing `download.json`, `parsed.json`, `ncbi_metadata.json`, `sample_sheet.csv`, plus downloaded files in `downloads/`. Step 6 aggregates all per-paper dirs into a final merged sample sheet.

**Shared utilities** (`src/utils.py`): git hash tracking, timestamped output paths, config loading, JSONL I/O, Gemini CLI wrapper (handles nested JSON + code fence unwrapping), `RateLimiter` class, `find_latest_output()`, `make_paper_dir()`.

**Config**: All settings in `config.yaml` — Entrez credentials, search query, screening criteria, Gemini timeout, output directories, sample sheet columns. No hard-coded values in step modules.

**Prompts**: Gemini prompt templates live in `prompts/` — `screening_prompt.txt`, `fulltext_parsing_prompt.txt`, `disease_mapping_prompt.txt`.

## Output Naming Convention

```
{name}_{YYYYMMDD}_{HHMM}_{git_hash}[_beyond].{ext}
```

- `git_hash`: 7-char short hash of the last commit
- `_beyond`: appended when working tree has uncommitted changes
- Creates full provenance: every output traces to exact code version

## Disease Status Inference (Step 6)

Priority order: (1) BioSample `disease` attribute → (2) dmfs/DMFS indices (both 0 = healthy, otherwise caries) → (3) sample group mapping from Gemini extraction → (4) `unknown`.

## Testing

Tests in `tests/` mock all NCBI and Gemini calls. Fixtures in `conftest.py` provide representative data (PRJNA613586, PMID 33051450). Tests write to `tmp_path`, not real `outputs/`. `test_per_paper.py` covers the `process_paper()` functions and end-to-end per-paper chaining.

## Environment Notes

- **Python 3.11+** required (uses `match` statements, `X | Y` union types)
- **`pip` blocked** by corporate proxy — use `uv pip install` for all packages
- **Gemini CLI** must be on PATH for steps 2 and 4 (steps degrade gracefully if missing)
- **NCBI access** may be blocked by corporate proxy — steps 1, 3, 4, 5 need `eutils.ncbi.nlm.nih.gov`
