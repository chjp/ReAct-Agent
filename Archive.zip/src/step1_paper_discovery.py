"""Step 1: PubMed search and abstract retrieval.

Searches PubMed for papers matching the configured query, fetches MEDLINE
records, and parses them into structured dicts.

Output: outputs/papers_YYYYMMDD_HHMM_{hash}.jsonl
"""

import re
from pathlib import Path

from Bio import Entrez

from utils import (
    RateLimiter,
    load_config,
    make_output_path,
    save_jsonl,
    setup_logging,
)

log = setup_logging("step1")


# ---------------------------------------------------------------------------
# PubMed search
# ---------------------------------------------------------------------------

def search_pubmed(query: str, max_results: int, config: dict) -> list[str]:
    """Search PubMed and return a list of PMIDs."""
    min_date = config.get("search", {}).get("min_date")
    kwargs: dict = dict(db="pubmed", term=query, retmax=str(max_results))
    if min_date:
        kwargs["mindate"] = min_date
        kwargs["datetype"] = "pdat"

    handle = Entrez.esearch(**kwargs)
    record = Entrez.read(handle)
    handle.close()

    pmids = record.get("IdList", [])
    log.info("PubMed search returned %d PMIDs", len(pmids))
    return pmids


# ---------------------------------------------------------------------------
# MEDLINE record parsing
# ---------------------------------------------------------------------------

def _parse_medline_records(text: str) -> list[dict]:
    """Parse MEDLINE-formatted text into a list of paper dicts."""
    papers = []
    for block in text.split("\n\n"):
        if not block.strip():
            continue
        paper = _parse_single_record(block)
        if paper:
            papers.append(paper)
    return papers


def _parse_single_record(record: str) -> dict | None:
    """Parse one MEDLINE record block into a dict."""
    pmid_m = re.search(r"^PMID- (\d+)", record, re.MULTILINE)
    if not pmid_m:
        return None

    title_m = re.search(
        r"^TI  - (.+?)(?=\n[A-Z]{2,4}  -|\Z)", record, re.MULTILINE | re.DOTALL
    )
    title = title_m.group(1).replace("\n      ", " ").strip() if title_m else ""

    abstract_m = re.search(
        r"^AB  - (.+?)(?=\n[A-Z]{2,4}  -|\Z)", record, re.MULTILINE | re.DOTALL
    )
    abstract = abstract_m.group(1).replace("\n      ", " ").strip() if abstract_m else ""

    doi_m = re.search(r"^AID - (10\.\S+) \[doi\]", record, re.MULTILINE)
    journal_m = re.search(r"^TA  - (.+)", record, re.MULTILINE)
    date_m = re.search(r"^DP  - (.+)", record, re.MULTILINE)

    pmc_m = re.search(r"^PMC - (PMC\d+)", record, re.MULTILINE)

    authors = [a.strip() for a in re.findall(r"^AU  - (.+)", record, re.MULTILINE)]
    mesh_terms = [m.strip() for m in re.findall(r"^MH  - (.+)", record, re.MULTILINE)]

    return {
        "pmid": pmid_m.group(1),
        "title": title,
        "abstract": abstract,
        "doi": doi_m.group(1) if doi_m else None,
        "pmc_id": pmc_m.group(1) if pmc_m else None,
        "journal": journal_m.group(1).strip() if journal_m else None,
        "pub_date": date_m.group(1).strip() if date_m else None,
        "authors": authors,
        "mesh_terms": mesh_terms,
    }


# ---------------------------------------------------------------------------
# Fetch abstracts
# ---------------------------------------------------------------------------

def fetch_abstracts(pmids: list[str], config: dict) -> list[dict]:
    """Fetch MEDLINE records for a list of PMIDs and parse them.

    Returns a list of paper dicts.
    """
    if not pmids:
        return []

    rate_limit = config.get("entrez", {}).get("rate_limit", 3)
    limiter = RateLimiter(rate_limit)

    # Fetch in batches of 200 (NCBI recommended max for efetch)
    all_papers = []
    batch_size = 200
    for i in range(0, len(pmids), batch_size):
        batch = pmids[i : i + batch_size]
        limiter.wait()
        log.info("Fetching MEDLINE records %d-%d of %d", i + 1, i + len(batch), len(pmids))

        handle = Entrez.efetch(
            db="pubmed", id=batch, rettype="medline", retmode="text"
        )
        text = handle.read()
        handle.close()

        papers = _parse_medline_records(text)
        all_papers.extend(papers)

    log.info("Parsed %d papers from %d PMIDs", len(all_papers), len(pmids))
    return all_papers


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run(config: dict) -> Path:
    """Execute step 1: search PubMed and save paper records.

    Returns the path to the output JSONL file.
    """
    # Configure Entrez
    Entrez.email = config.get("entrez", {}).get("email", "researcher@example.com")
    api_key = config.get("entrez", {}).get("api_key")
    if api_key:
        Entrez.api_key = api_key

    query = config["search"]["query"]
    max_results = config["search"].get("max_results", 50)

    log.info("Step 1: Paper Discovery — query=%r, max=%d", query, max_results)

    pmids = search_pubmed(query, max_results, config)
    papers = fetch_abstracts(pmids, config)

    output_path = make_output_path("papers", "jsonl", config)
    save_jsonl(papers, output_path)
    log.info("Saved %d papers to %s", len(papers), output_path)

    return output_path


if __name__ == "__main__":
    cfg = load_config()
    run(cfg)
