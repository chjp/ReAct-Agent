"""Step 4: Parse full-text papers to extract BioProject IDs and study metadata.

Uses Gemini CLI for AI-powered extraction from full text, and NCBI E-utilities
for cross-referencing BioProject/SRA links.

Output: outputs/parsed_YYYYMMDD_HHMM_{hash}.jsonl
"""

import re
from pathlib import Path

from Bio import Entrez

from utils import (
    RateLimiter,
    call_gemini,
    find_latest_output,
    load_config,
    load_jsonl,
    make_output_path,
    make_paper_dir,
    save_jsonl,
    setup_logging,
)

log = setup_logging("step4")


# ---------------------------------------------------------------------------
# Gemini full-text parsing
# ---------------------------------------------------------------------------

def _load_prompt_template() -> str:
    prompt_path = Path(__file__).parent.parent / "prompts" / "fulltext_parsing_prompt.txt"
    return prompt_path.read_text()


def parse_fulltext_with_gemini(paper_text: str, config: dict) -> dict | None:
    """Send full text to Gemini and extract structured metadata."""
    template = _load_prompt_template()
    prompt = template.format(paper_text=paper_text[:30000])  # truncate to avoid token limits
    timeout = config.get("gemini", {}).get("timeout", 60)
    return call_gemini(prompt, timeout=timeout)


# ---------------------------------------------------------------------------
# NCBI E-utilities cross-linking
# ---------------------------------------------------------------------------

def find_ncbi_links(pmid: str, limiter: RateLimiter) -> dict:
    """Find BioProject and SRA IDs linked to a PMID via NCBI E-utilities."""
    result = {"bioproject_ids": [], "sra_ids": []}

    # PubMed → BioProject
    try:
        limiter.wait()
        handle = Entrez.elink(dbfrom="pubmed", db="bioproject", id=pmid)
        link_result = Entrez.read(handle)
        handle.close()

        if link_result and link_result[0].get("LinkSetDb"):
            for link_set in link_result[0]["LinkSetDb"]:
                for link in link_set.get("Link", []):
                    bp_uid = link["Id"]
                    limiter.wait()
                    handle = Entrez.efetch(db="bioproject", id=bp_uid, rettype="xml")
                    bp_xml = handle.read()
                    handle.close()
                    if isinstance(bp_xml, bytes):
                        bp_xml = bp_xml.decode("utf-8")
                    m = re.search(r'<ArchiveID id="(PRJNA\d+)"', bp_xml)
                    if m:
                        result["bioproject_ids"].append(m.group(1))
    except Exception as e:
        log.warning("BioProject elink failed for PMID %s: %s", pmid, e)

    # PubMed → SRA
    try:
        limiter.wait()
        handle = Entrez.elink(dbfrom="pubmed", db="sra", id=pmid)
        link_result = Entrez.read(handle)
        handle.close()

        if link_result and link_result[0].get("LinkSetDb"):
            for link_set in link_result[0]["LinkSetDb"]:
                for link in link_set.get("Link", []):
                    result["sra_ids"].append(link["Id"])
    except Exception as e:
        log.warning("SRA elink failed for PMID %s: %s", pmid, e)

    return result


# ---------------------------------------------------------------------------
# Supplement parsing (best-effort)
# ---------------------------------------------------------------------------

def parse_supplement(path: Path) -> dict | None:
    """Attempt to parse a supplement file and extract useful data.

    Returns a dict of extracted info, or None if parsing fails.
    """
    suffix = path.suffix.lower()

    if suffix in (".xlsx", ".xls"):
        return _parse_excel_supplement(path)
    elif suffix in (".csv", ".tsv"):
        return _parse_csv_supplement(path)
    else:
        # PDF and DOCX are logged for orchestrator to handle with skills
        log.info("Supplement %s needs manual processing (type: %s)", path.name, suffix)
        return None


def _parse_excel_supplement(path: Path) -> dict | None:
    try:
        import pandas as pd
        df = pd.read_excel(path, engine="openpyxl")
        columns = list(df.columns)
        return {
            "file": path.name,
            "type": "excel",
            "rows": len(df),
            "columns": columns,
            "sample_id_columns": [c for c in columns if any(
                kw in c.lower() for kw in ("sample", "id", "accession", "sra", "run")
            )],
            "preview": df.head(5).to_dict(orient="records"),
        }
    except Exception as e:
        log.warning("Failed to parse Excel supplement %s: %s", path, e)
        return None


def _parse_csv_supplement(path: Path) -> dict | None:
    try:
        import pandas as pd
        sep = "\t" if path.suffix == ".tsv" else ","
        df = pd.read_csv(path, sep=sep)
        columns = list(df.columns)
        return {
            "file": path.name,
            "type": "csv",
            "rows": len(df),
            "columns": columns,
            "sample_id_columns": [c for c in columns if any(
                kw in c.lower() for kw in ("sample", "id", "accession", "sra", "run")
            )],
            "preview": df.head(5).to_dict(orient="records"),
        }
    except Exception as e:
        log.warning("Failed to parse CSV supplement %s: %s", path, e)
        return None


# ---------------------------------------------------------------------------
# Per-paper processing
# ---------------------------------------------------------------------------

def process_paper(download_record: dict, config: dict, limiter: RateLimiter) -> dict:
    """Parse a single paper and extract BioProject IDs / metadata.

    Args:
        download_record: A single step 3 output dict (with pmid, fulltext_path, etc.).
        config: Pipeline configuration dict.
        limiter: Shared RateLimiter instance.

    Returns:
        Parsed record dict with an ``error`` key (None on success).
    """
    pmid = download_record["pmid"]
    paper_dir = make_paper_dir(pmid, config)

    record = {
        "pmid": pmid,
        "title": download_record.get("title", ""),
        "pmc_id": download_record.get("pmc_id"),
        "fulltext_available": download_record.get("fulltext_available", False),
        "gemini_metadata": None,
        "ncbi_links": None,
        "supplement_data": [],
        "bioproject_ids": [],
        "error": None,
    }

    try:
        log.info("Parsing PMID %s", pmid)

        # NCBI E-utilities cross-linking
        ncbi_links = find_ncbi_links(pmid, limiter)
        record["ncbi_links"] = ncbi_links

        # Gemini extraction from full text (if available)
        fulltext_path = download_record.get("fulltext_path")
        if fulltext_path and Path(fulltext_path).exists():
            text = Path(fulltext_path).read_text(encoding="utf-8")
            gemini_result = parse_fulltext_with_gemini(text, config)
            record["gemini_metadata"] = gemini_result
        else:
            log.info("PMID %s: no full text available, using NCBI links only", pmid)

        # Parse supplements
        for supp in download_record.get("supplements", []):
            supp_path = Path(supp["path"])
            if supp_path.exists():
                parsed = parse_supplement(supp_path)
                if parsed:
                    record["supplement_data"].append(parsed)

        # Merge BioProject IDs from all sources
        bp_ids = set(ncbi_links.get("bioproject_ids", []))
        if record["gemini_metadata"]:
            bp_ids.update(record["gemini_metadata"].get("bioproject_ids") or [])
        record["bioproject_ids"] = sorted(bp_ids)
    except Exception as e:
        log.error("PMID %s: step 4 failed: %s", pmid, e)
        record["error"] = str(e)

    # Save per-paper result
    import json
    result_path = paper_dir / "parsed.json"
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(record, f, indent=2, ensure_ascii=False)

    return record


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run(config: dict, downloads_path: Path | None = None) -> Path:
    """Execute step 4: parse papers and extract metadata.

    Args:
        config: Pipeline configuration dict.
        downloads_path: Path to step 3 download manifest. Auto-discovered if None.

    Returns:
        Path to the parsed output JSONL.
    """
    log.info("Step 4: Paper Parsing")

    Entrez.email = config.get("entrez", {}).get("email", "researcher@example.com")
    api_key = config.get("entrez", {}).get("api_key")
    if api_key:
        Entrez.api_key = api_key

    rate_limit = config.get("entrez", {}).get("rate_limit", 3)
    limiter = RateLimiter(rate_limit)

    if downloads_path is None:
        downloads_path = find_latest_output("downloads", config.get("output", {}).get("dir", "outputs"))
    if downloads_path is None:
        raise FileNotFoundError("No downloads manifest found. Run step 3 first.")

    manifest = load_jsonl(downloads_path)
    log.info("Loaded download manifest with %d entries", len(manifest))

    parsed_records = []
    for entry in manifest:
        record = process_paper(entry, config, limiter)
        parsed_records.append(record)

    with_bp = sum(1 for r in parsed_records if r["bioproject_ids"])
    log.info("Parsing complete: %d/%d papers have BioProject IDs", with_bp, len(parsed_records))

    output_path = make_output_path("parsed", "jsonl", config)
    save_jsonl(parsed_records, output_path)
    log.info("Saved parsed metadata to %s", output_path)

    return output_path


if __name__ == "__main__":
    cfg = load_config()
    run(cfg)
