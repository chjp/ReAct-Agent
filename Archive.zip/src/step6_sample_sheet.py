"""Step 6: Merge paper and NCBI metadata into analysis-ready sample sheets.

Joins BioSample attributes with SRA run IDs, normalizes column names,
infers disease status, and outputs a CSV plus a summary JSON.

Output: outputs/sample_sheet_YYYYMMDD_HHMM_{hash}.csv
        outputs/sample_sheet_summary_YYYYMMDD_HHMM_{hash}.json
"""

import json
import re
from pathlib import Path

import pandas as pd

from utils import (
    call_gemini,
    find_latest_output,
    load_config,
    load_jsonl,
    make_output_path,
    make_paper_dir,
    save_jsonl,
    setup_logging,
)

log = setup_logging("step6")


# ---------------------------------------------------------------------------
# Merge paper + NCBI data
# ---------------------------------------------------------------------------

def merge_paper_and_ncbi(parsed_records: list[dict], ncbi_records: list[dict]) -> pd.DataFrame:
    """Join NCBI BioSample/SRA data with paper-level metadata.

    Returns a DataFrame with one row per SRA run.
    """
    # Build lookup: bioproject_id → ncbi record
    ncbi_by_bp = {r["bioproject_id"]: r for r in ncbi_records}

    # Build lookup: bioproject_id → paper metadata
    paper_by_bp: dict[str, dict] = {}
    for rec in parsed_records:
        for bp_id in rec.get("bioproject_ids", []):
            paper_by_bp[bp_id] = rec

    rows = []
    for bp_id, ncbi_rec in ncbi_by_bp.items():
        paper_rec = paper_by_bp.get(bp_id, {})
        pmid = paper_rec.get("pmid", "")

        # Build biosample accession → attributes lookup
        bs_attrs = {}
        for bs in ncbi_rec.get("biosamples", []):
            acc = bs.get("accession", bs.get("biosample_id", ""))
            bs_attrs[acc] = bs.get("attributes", {})

        # One row per SRA run
        for run in ncbi_rec.get("sra_runs", []):
            run_acc = run.get("run_accession", "")
            bs_acc = run.get("biosample_accession", "")
            attrs = bs_attrs.get(bs_acc, {})

            row = {
                "sample_name": bs_acc or run_acc,
                "sra_run_id": run_acc,
                "bioproject_id": bp_id,
                "biosample_accession": bs_acc,
                "pmid": pmid,
                "experiment_accession": run.get("experiment_accession", ""),
                "platform": run.get("platform", ""),
                "library_strategy": run.get("library_strategy", ""),
            }
            # Flatten BioSample attributes
            row.update(attrs)
            rows.append(row)

    df = pd.DataFrame(rows)
    log.info("Merged %d SRA runs across %d BioProjects", len(df), len(ncbi_by_bp))
    return df


# ---------------------------------------------------------------------------
# Normalize column names and values
# ---------------------------------------------------------------------------

# Map common BioSample attribute names to standardized columns
COLUMN_ALIASES = {
    "host_sex": ["sex", "gender", "host sex", "host_sex"],
    "host_age": ["age", "host age", "host_age", "age (years)"],
    "geographic_location": [
        "geo_loc_name", "geographic location", "geographic_location",
        "country", "geo_loc_name_country", "geo_loc_name_country_continent",
    ],
    "host": ["host", "organism", "host organism"],
    "isolation_source": ["isolation_source", "isolation source", "tissue", "sample_type"],
}

SEX_NORMALIZE = {
    "m": "male", "f": "female", "male": "male", "female": "female",
    "man": "male", "woman": "female", "boy": "male", "girl": "female",
}


def normalize_attributes(df: pd.DataFrame) -> pd.DataFrame:
    """Standardize column names and values."""
    # Normalize column names
    for standard_name, aliases in COLUMN_ALIASES.items():
        if standard_name not in df.columns:
            for alias in aliases:
                matching = [c for c in df.columns if c.lower() == alias.lower()]
                if matching:
                    df = df.rename(columns={matching[0]: standard_name})
                    break

    # Normalize sex values
    if "host_sex" in df.columns:
        df["host_sex"] = df["host_sex"].astype(str).str.lower().str.strip().map(
            lambda v: SEX_NORMALIZE.get(v, v)
        )

    return df


# ---------------------------------------------------------------------------
# Disease status inference
# ---------------------------------------------------------------------------

def infer_disease_status(row: pd.Series, paper_metadata: dict | None = None) -> str:
    """Determine caries status for a single sample.

    Priority order:
    1. BioSample "disease" attribute
    2. dmfs/DMFS indices
    3. Sample group mapping from paper metadata
    4. "unknown"
    """
    # 1. Direct disease attribute
    disease = str(row.get("disease", "")).lower().strip()
    if "caries" in disease:
        return "caries"
    if disease in ("healthy", "normal", "none", "control"):
        return "healthy"

    # Also check "health state" and similar attributes
    for col in ("health_state", "health state", "disease_status", "phenotype"):
        val = str(row.get(col, "")).lower().strip()
        if "caries" in val:
            return "caries"
        if val in ("healthy", "normal", "none", "control"):
            return "healthy"

    # 2. dmfs/DMFS indices
    dmfs = _parse_index(row, "dmfs-index", "dmfs_index", "dmfs")
    DMFS = _parse_index(row, "DMFS-index", "DMFS_index", "DMFS")
    if dmfs is not None or DMFS is not None:
        dmfs_val = dmfs if dmfs is not None else 0
        DMFS_val = DMFS if DMFS is not None else 0
        return "healthy" if (dmfs_val == 0 and DMFS_val == 0) else "caries"

    # 3. Paper sample group mapping
    if paper_metadata and paper_metadata.get("gemini_metadata"):
        groups = paper_metadata["gemini_metadata"].get("sample_groups") or []
        for group in groups:
            group_name = (group.get("group_name") or "").lower()
            desc = (group.get("description") or "").lower()
            if "caries" in group_name or "caries" in desc:
                # Could try matching by sample count / biosample position
                pass

    return "unknown"


def _parse_index(row: pd.Series, *col_names: str) -> float | None:
    """Try to parse a numeric index from various column name variants."""
    for col in col_names:
        if col in row.index:
            try:
                val = float(row[col])
                return val
            except (ValueError, TypeError):
                continue
    return None


# ---------------------------------------------------------------------------
# Summary generation
# ---------------------------------------------------------------------------

def generate_summary(df: pd.DataFrame, parsed_records: list[dict]) -> dict:
    """Generate a summary report of the sample sheet."""
    summary = {
        "total_samples": len(df),
        "total_bioprojects": df["bioproject_id"].nunique() if "bioproject_id" in df.columns else 0,
        "total_pmids": df["pmid"].nunique() if "pmid" in df.columns else 0,
    }

    if "caries_status" in df.columns:
        status_counts = df["caries_status"].value_counts().to_dict()
        summary["caries_status_breakdown"] = status_counts
        summary["pct_classified"] = round(
            100 * (1 - status_counts.get("unknown", 0) / max(len(df), 1)), 1
        )

    # Completeness metrics
    required = ["sample_name", "sra_run_id", "bioproject_id", "pmid", "caries_status"]
    completeness = {}
    for col in required:
        if col in df.columns:
            non_null = df[col].notna().sum()
            non_empty = (df[col].astype(str).str.strip() != "").sum()
            completeness[col] = round(100 * min(non_null, non_empty) / max(len(df), 1), 1)
        else:
            completeness[col] = 0.0
    summary["column_completeness_pct"] = completeness

    # Per-BioProject breakdown
    if "bioproject_id" in df.columns:
        bp_summary = []
        for bp_id, group in df.groupby("bioproject_id"):
            bp_info = {"bioproject_id": bp_id, "sample_count": len(group)}
            if "caries_status" in group.columns:
                bp_info["status_breakdown"] = group["caries_status"].value_counts().to_dict()
            bp_summary.append(bp_info)
        summary["bioprojects"] = bp_summary

    return summary


# ---------------------------------------------------------------------------
# Per-paper processing
# ---------------------------------------------------------------------------

def process_paper(parsed_record: dict, ncbi_record: dict, config: dict) -> pd.DataFrame:
    """Generate a sample sheet for a single paper.

    Args:
        parsed_record: A single step 4 output dict.
        ncbi_record: A single step 5 per-paper output dict
            (with ``bioprojects`` list containing biosamples/sra_runs).
        config: Pipeline configuration dict.

    Returns:
        DataFrame with one row per SRA run for this paper.
    """
    pmid = parsed_record["pmid"]
    paper_dir = make_paper_dir(pmid, config)

    # Convert per-paper ncbi_record into the BioProject-centric list that
    # merge_paper_and_ncbi expects.
    ncbi_records_flat = []
    for bp in ncbi_record.get("bioprojects", []):
        ncbi_records_flat.append({
            "bioproject_id": bp["bioproject_id"],
            "pmids": [pmid],
            "biosample_count": bp.get("biosample_count", len(bp.get("biosamples", []))),
            "biosamples": bp.get("biosamples", []),
            "sra_run_count": bp.get("sra_run_count", len(bp.get("sra_runs", []))),
            "sra_runs": bp.get("sra_runs", []),
        })

    df = merge_paper_and_ncbi([parsed_record], ncbi_records_flat)
    if df.empty:
        log.info("PMID %s: no samples to generate", pmid)
        csv_path = paper_dir / "sample_sheet.csv"
        df.to_csv(csv_path, index=False)
        return df

    df = normalize_attributes(df)

    paper_by_bp = {bp_id: parsed_record for bp_id in parsed_record.get("bioproject_ids", [])}
    df["caries_status"] = df.apply(
        lambda row: infer_disease_status(row, paper_by_bp.get(row.get("bioproject_id"))),
        axis=1,
    )

    # Reorder columns
    required = config.get("sample_sheet", {}).get("required_columns", [])
    existing_required = [c for c in required if c in df.columns]
    other_cols = [c for c in df.columns if c not in existing_required]
    df = df[existing_required + other_cols]

    csv_path = paper_dir / "sample_sheet.csv"
    df.to_csv(csv_path, index=False)
    log.info("PMID %s: saved per-paper sample sheet (%d rows) to %s", pmid, len(df), csv_path)

    return df


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def _collect_per_paper_data(output_dir: Path) -> tuple[list[dict], list[dict]]:
    """Scan outputs/PMID_*/ dirs and load parsed.json + ncbi_metadata.json.

    Returns (parsed_records, ncbi_records_flat) in the formats that
    merge_paper_and_ncbi expects.
    """
    parsed_records = []
    ncbi_records_flat = []
    seen_bioprojects: set[str] = set()

    for paper_dir in sorted(output_dir.glob("PMID_*")):
        parsed_file = paper_dir / "parsed.json"
        ncbi_file = paper_dir / "ncbi_metadata.json"

        if not parsed_file.exists():
            continue

        with open(parsed_file) as f:
            parsed_rec = json.load(f)
        parsed_records.append(parsed_rec)

        if ncbi_file.exists():
            with open(ncbi_file) as f:
                ncbi_rec = json.load(f)
            for bp in ncbi_rec.get("bioprojects", []):
                bp_id = bp["bioproject_id"]
                if bp_id not in seen_bioprojects:
                    seen_bioprojects.add(bp_id)
                    ncbi_records_flat.append({
                        "bioproject_id": bp_id,
                        "pmids": [parsed_rec["pmid"]],
                        "biosample_count": bp.get("biosample_count", len(bp.get("biosamples", []))),
                        "biosamples": bp.get("biosamples", []),
                        "sra_run_count": bp.get("sra_run_count", len(bp.get("sra_runs", []))),
                        "sra_runs": bp.get("sra_runs", []),
                    })

    return parsed_records, ncbi_records_flat


def run(config: dict, parsed_path: Path | None = None, ncbi_path: Path | None = None) -> Path:
    """Execute step 6: generate analysis-ready sample sheet.

    Supports two modes:
    - **Per-paper aggregation** (default): scans ``outputs/PMID_*/`` for
      ``parsed.json`` and ``ncbi_metadata.json`` produced by per-paper
      processing.
    - **Batch fallback**: uses batch JSONL files from steps 4+5 if no
      per-paper directories exist.

    Args:
        config: Pipeline configuration dict.
        parsed_path: Path to step 4 batch output. Auto-discovered if None.
        ncbi_path: Path to step 5 batch output. Auto-discovered if None.

    Returns:
        Path to the merged sample sheet CSV.
    """
    log.info("Step 6: Sample Sheet Generation")

    output_dir = Path(config.get("output", {}).get("dir", "outputs"))

    # Try per-paper aggregation first
    per_paper_dirs = list(output_dir.glob("PMID_*"))
    if per_paper_dirs and parsed_path is None and ncbi_path is None:
        log.info("Found %d per-paper directories, aggregating", len(per_paper_dirs))
        parsed_records, ncbi_records = _collect_per_paper_data(output_dir)
    else:
        # Batch fallback
        if parsed_path is None:
            parsed_path = find_latest_output("parsed", str(output_dir))
        if parsed_path is None:
            raise FileNotFoundError("No parsed file found. Run step 4 first.")

        if ncbi_path is None:
            ncbi_path = find_latest_output("ncbi_metadata", str(output_dir))
        if ncbi_path is None:
            raise FileNotFoundError("No NCBI metadata file found. Run step 5 first.")

        parsed_records = load_jsonl(parsed_path)
        ncbi_records = load_jsonl(ncbi_path)

    # Build paper metadata lookup by bioproject
    paper_by_bp = {}
    for rec in parsed_records:
        for bp_id in rec.get("bioproject_ids", []):
            paper_by_bp[bp_id] = rec

    # Merge
    df = merge_paper_and_ncbi(parsed_records, ncbi_records)
    if df.empty:
        log.warning("No samples to generate sample sheet")
        output_path = make_output_path("sample_sheet", "csv", config)
        df.to_csv(output_path, index=False)
        return output_path

    # Normalize
    df = normalize_attributes(df)

    # Infer disease status
    df["caries_status"] = df.apply(
        lambda row: infer_disease_status(row, paper_by_bp.get(row.get("bioproject_id"))),
        axis=1,
    )

    # Reorder columns: required columns first
    required = config.get("sample_sheet", {}).get("required_columns", [])
    existing_required = [c for c in required if c in df.columns]
    other_cols = [c for c in df.columns if c not in existing_required]
    df = df[existing_required + other_cols]

    # Save CSV
    csv_path = make_output_path("sample_sheet", "csv", config)
    df.to_csv(csv_path, index=False)
    log.info("Saved sample sheet (%d rows) to %s", len(df), csv_path)

    # Save summary JSON
    summary = generate_summary(df, parsed_records)
    summary_path = make_output_path("sample_sheet_summary", "json", config)
    with open(summary_path, "w") as f:
        json.dump(summary, f, indent=2)
    log.info("Saved summary to %s", summary_path)

    # Print summary
    log.info("=== Sample Sheet Summary ===")
    log.info("Total samples: %d", summary["total_samples"])
    log.info("BioProjects: %d", summary["total_bioprojects"])
    if "caries_status_breakdown" in summary:
        for status, count in summary["caries_status_breakdown"].items():
            log.info("  %s: %d", status, count)
    log.info("Classification rate: %.1f%%", summary.get("pct_classified", 0))

    return csv_path


if __name__ == "__main__":
    cfg = load_config()
    run(cfg)
