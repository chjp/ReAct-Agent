"""Shared utilities for the fromfresh pipeline."""

import json
import logging
import subprocess
import time
from datetime import datetime
from pathlib import Path

import yaml


def get_git_hash() -> str:
    """Get current git commit short hash (7 chars)."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--short", "HEAD"],
            capture_output=True, text=True, check=True,
        )
        return result.stdout.strip()
    except Exception:
        return "nogit"


def has_uncommitted_changes() -> bool:
    """Check if git working tree has uncommitted changes."""
    try:
        result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True, text=True, check=True,
        )
        return bool(result.stdout.strip())
    except Exception:
        return False


def make_output_path(base_name: str, ext: str, config: dict) -> Path:
    """Build a timestamped, git-hash-tagged output path.

    Returns e.g. outputs/papers_20260208_1430_abc1234_beyond.jsonl
    """
    output_dir = Path(config.get("output", {}).get("dir", "outputs"))
    output_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M")
    git_hash = get_git_hash()
    beyond = "_beyond" if has_uncommitted_changes() else ""
    filename = f"{base_name}_{timestamp}_{git_hash}{beyond}.{ext}"
    return output_dir / filename


def load_config(path: str | Path = "config.yaml") -> dict:
    """Load YAML config file."""
    with open(path, "r") as f:
        return yaml.safe_load(f)


def setup_logging(name: str, level: int = logging.INFO) -> logging.Logger:
    """Configure and return a logger."""
    logger = logging.getLogger(name)
    if not logger.handlers:
        handler = logging.StreamHandler()
        fmt = logging.Formatter(
            "%(asctime)s [%(name)s] %(levelname)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        handler.setFormatter(fmt)
        logger.addHandler(handler)
    logger.setLevel(level)
    return logger


def call_gemini(prompt: str, input_text: str = "", timeout: int = 60) -> dict | None:
    """Call Gemini CLI and return parsed JSON response.

    Handles the nested JSON + markdown code block unwrapping that Gemini
    sometimes produces.

    Returns parsed dict on success, None on failure.
    """
    try:
        full_input = input_text if input_text else ""
        result = subprocess.run(
            ["gemini", "-p", prompt, "--output-format", "json"],
            input=full_input,
            capture_output=True,
            text=True,
            timeout=timeout,
        )

        if result.returncode != 0:
            logging.getLogger("gemini").warning(
                "Gemini CLI failed (rc=%d): %s", result.returncode, result.stderr
            )
            return None

        raw = result.stdout.strip()
        return _parse_gemini_output(raw)

    except subprocess.TimeoutExpired:
        logging.getLogger("gemini").warning("Gemini CLI timed out (%ds)", timeout)
        return None
    except FileNotFoundError:
        logging.getLogger("gemini").error("Gemini CLI not found on PATH")
        return None
    except Exception as e:
        logging.getLogger("gemini").warning("Gemini CLI error: %s", e)
        return None


def _parse_gemini_output(raw: str) -> dict | None:
    """Parse Gemini output, handling nested JSON and code-block wrapping."""
    # First try: direct JSON parse
    try:
        data = json.loads(raw)
        # Gemini sometimes wraps in {"response": "..."}
        if isinstance(data, dict) and "response" in data and len(data) == 1:
            return _unwrap_response(data["response"])
        return data
    except json.JSONDecodeError:
        pass

    # Second try: strip markdown code fences
    text = _strip_code_fences(raw)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        logging.getLogger("gemini").warning("Could not parse Gemini output as JSON")
        return None


def _unwrap_response(response_text: str) -> dict | None:
    """Unwrap a Gemini response string that may contain code-fenced JSON."""
    text = _strip_code_fences(response_text)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def _strip_code_fences(text: str) -> str:
    """Remove ```json ... ``` or ``` ... ``` wrappers."""
    text = text.strip()
    if text.startswith("```json"):
        text = text[7:]
    elif text.startswith("```"):
        text = text[3:]
    if text.endswith("```"):
        text = text[:-3]
    return text.strip()


def save_jsonl(records: list[dict], path: Path) -> Path:
    """Write a list of dicts as newline-delimited JSON."""
    with open(path, "w", encoding="utf-8") as f:
        for rec in records:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
    return path


def load_jsonl(path: Path) -> list[dict]:
    """Read a JSONL file into a list of dicts."""
    records = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                records.append(json.loads(line))
    return records


def find_latest_output(prefix: str, output_dir: str | Path = "outputs") -> Path | None:
    """Find the most recent output file matching a prefix.

    Scans output_dir for files starting with prefix, returns the one with
    the latest modification time, or None if no match.
    """
    output_dir = Path(output_dir)
    if not output_dir.exists():
        return None
    matches = sorted(output_dir.glob(f"{prefix}*"), key=lambda p: p.stat().st_mtime)
    return matches[-1] if matches else None


def make_paper_dir(pmid: str, config: dict) -> Path:
    """Create and return a per-paper output directory: outputs/PMID_{pmid}/."""
    output_dir = Path(config.get("output", {}).get("dir", "outputs"))
    paper_dir = output_dir / f"PMID_{pmid}"
    paper_dir.mkdir(parents=True, exist_ok=True)
    return paper_dir


class RateLimiter:
    """Simple rate limiter for API calls."""

    def __init__(self, requests_per_second: int = 3):
        self._interval = 1.0 / requests_per_second
        self._last_call = 0.0

    def wait(self):
        """Block until enough time has elapsed since the last call."""
        now = time.monotonic()
        elapsed = now - self._last_call
        if elapsed < self._interval:
            time.sleep(self._interval - elapsed)
        self._last_call = time.monotonic()
