"""Step 3: Download full-text articles and supplements from PMC Open Access.

For each screened-relevant paper, checks PMC availability via E-utilities elink,
downloads the OA package (.tar.gz), and extracts JATS XML full text.

Output: outputs/downloads_YYYYMMDD_HHMM_{hash}.jsonl  (manifest)
Files:  downloads/PMID_{pmid}/  (extracted packages)
"""

import tarfile
from pathlib import Path

import requests
from Bio import Entrez
from lxml import etree

from utils import (
    RateLimiter,
    find_latest_output,
    load_config,
    load_jsonl,
    make_output_path,
    make_paper_dir,
    save_jsonl,
    setup_logging,
)

log = setup_logging("step3")

PMC_OA_API = "https://www.ncbi.nlm.nih.gov/pmc/utils/oa/oa.fcgi"


# ---------------------------------------------------------------------------
# PMC availability check
# ---------------------------------------------------------------------------

def check_pmc_availability(pmid: str, limiter: RateLimiter) -> str | None:
    """Check if a PMID has a corresponding PMC open-access article.

    Returns the PMC ID (e.g. "PMC7654321") or None.
    """
    limiter.wait()
    try:
        handle = Entrez.elink(dbfrom="pubmed", db="pmc", id=pmid)
        result = Entrez.read(handle)
        handle.close()

        if result and result[0].get("LinkSetDb"):
            for link_set in result[0]["LinkSetDb"]:
                for link in link_set.get("Link", []):
                    return f"PMC{link['Id']}"
    except Exception as e:
        log.warning("elink failed for PMID %s: %s", pmid, e)
    return None


# ---------------------------------------------------------------------------
# Download OA package
# ---------------------------------------------------------------------------

def download_pmc_package(pmc_id: str, download_dir: Path, limiter: RateLimiter) -> Path | None:
    """Download and extract the PMC OA package for a given PMC ID.

    Returns the directory containing extracted files, or None on failure.
    """
    limiter.wait()
    try:
        resp = requests.get(PMC_OA_API, params={"id": pmc_id}, timeout=30)
        resp.raise_for_status()
    except requests.RequestException as e:
        log.warning("OA API request failed for %s: %s", pmc_id, e)
        return None

    # Parse the OA response XML to find the download link
    try:
        root = etree.fromstring(resp.content)
    except etree.XMLSyntaxError:
        log.warning("Invalid XML from OA API for %s", pmc_id)
        return None

    # Look for FTP or HTTPS link in the OA response
    link_el = root.find(".//link[@format='tgz']")
    if link_el is None:
        # Try PDF as fallback
        link_el = root.find(".//link[@format='pdf']")
    if link_el is None:
        log.info("%s not available in OA subset", pmc_id)
        return None

    href = link_el.get("href", "")
    if not href:
        return None

    # Convert FTP to HTTPS if needed
    if href.startswith("ftp://"):
        href = href.replace("ftp://ftp.ncbi.nlm.nih.gov/", "https://ftp.ncbi.nlm.nih.gov/")

    # Download the tarball
    out_dir = download_dir / pmc_id
    out_dir.mkdir(parents=True, exist_ok=True)

    if href.endswith(".tar.gz") or href.endswith(".tgz"):
        tgz_path = out_dir / "package.tar.gz"
        try:
            log.info("Downloading %s", href)
            dl = requests.get(href, timeout=120, stream=True)
            dl.raise_for_status()
            with open(tgz_path, "wb") as f:
                for chunk in dl.iter_content(chunk_size=8192):
                    f.write(chunk)

            with tarfile.open(tgz_path, "r:gz") as tar:
                tar.extractall(path=out_dir, filter="data")
            tgz_path.unlink()  # Remove tarball after extraction
            return out_dir
        except Exception as e:
            log.warning("Download/extract failed for %s: %s", pmc_id, e)
            return None
    elif href.endswith(".pdf"):
        pdf_path = out_dir / "article.pdf"
        try:
            dl = requests.get(href, timeout=120)
            dl.raise_for_status()
            pdf_path.write_bytes(dl.content)
            return out_dir
        except Exception as e:
            log.warning("PDF download failed for %s: %s", pmc_id, e)
            return None

    return None


# ---------------------------------------------------------------------------
# JATS XML text extraction
# ---------------------------------------------------------------------------

def extract_text_from_jats(xml_path: Path) -> str:
    """Extract plain text from a JATS/NLM XML article.

    Extracts abstract, body paragraphs, and data-availability sections.
    """
    try:
        tree = etree.parse(str(xml_path))
    except etree.XMLSyntaxError as e:
        log.warning("Failed to parse JATS XML %s: %s", xml_path, e)
        return ""

    root = tree.getroot()
    parts = []

    # Abstract
    for abstract in root.iter("abstract"):
        parts.append(_element_text(abstract))

    # Body paragraphs
    for body in root.iter("body"):
        parts.append(_element_text(body))

    # Data availability / data access section
    for sec in root.iter("sec"):
        sec_type = sec.get("sec-type", "")
        title_el = sec.find("title")
        title_text = (title_el.text or "").lower() if title_el is not None else ""
        if "data" in sec_type.lower() or "data" in title_text or "accession" in title_text:
            parts.append(_element_text(sec))

    return "\n\n".join(p for p in parts if p.strip())


def _element_text(el) -> str:
    """Recursively extract all text from an lxml element."""
    return "".join(el.itertext()).strip()


# ---------------------------------------------------------------------------
# Find supplement files
# ---------------------------------------------------------------------------

def download_supplements_from_xml(
    xml_path: Path, pmc_id: str, download_dir: Path, limiter: RateLimiter
) -> list[Path]:
    """Parse JATS XML for supplementary-material links and download them.

    Downloads supplement files referenced in ``<supplementary-material>``
    elements that are not already present in *download_dir*.

    Returns a list of paths to newly downloaded files.
    """
    try:
        tree = etree.parse(str(xml_path))
    except etree.XMLSyntaxError as e:
        log.warning("Failed to parse XML for supplements %s: %s", xml_path, e)
        return []

    root = tree.getroot()
    downloaded: list[Path] = []
    base_url = f"https://www.ncbi.nlm.nih.gov/pmc/articles/{pmc_id}/bin"

    NSMAP = {"xlink": "http://www.w3.org/1999/xlink"}

    for elem in root.iter("supplementary-material"):
        href = elem.get("{http://www.w3.org/1999/xlink}href")
        if not href:
            continue

        filename = href.split("/")[-1]
        dest = download_dir / filename
        if dest.exists():
            log.debug("Supplement already present, skipping: %s", filename)
            continue

        url = f"{base_url}/{filename}"
        limiter.wait()
        try:
            log.info("Downloading supplement %s", url)
            resp = requests.get(url, timeout=60)
            resp.raise_for_status()
            dest.write_bytes(resp.content)
            downloaded.append(dest)
        except requests.RequestException as e:
            log.warning("Failed to download supplement %s: %s", url, e)

    return downloaded


def find_supplements(pkg_dir: Path) -> list[dict]:
    """Scan a downloaded PMC package directory for supplement files."""
    supplements = []
    for ext in ("*.xlsx", "*.xls", "*.csv", "*.tsv", "*.pdf", "*.docx", "*.doc"):
        for f in pkg_dir.rglob(ext):
            supplements.append({"path": str(f), "name": f.name, "type": f.suffix})
    return supplements


# ---------------------------------------------------------------------------
# Per-paper processing
# ---------------------------------------------------------------------------

def process_paper(paper: dict, config: dict, limiter: RateLimiter) -> dict:
    """Download full text for a single paper.

    Args:
        paper: Screening record dict with at least ``pmid`` and ``title``.
        config: Pipeline configuration dict.
        limiter: Shared RateLimiter instance.

    Returns:
        Download record dict (same schema as batch manifest entries) with an
        ``error`` key (None on success, error string on failure).
    """
    pmid = paper["pmid"]
    paper_dir = make_paper_dir(pmid, config)
    download_dir = paper_dir / "downloads"
    download_dir.mkdir(parents=True, exist_ok=True)

    entry = {
        "pmid": pmid,
        "title": paper.get("title", ""),
        "pmc_id": None,
        "downloaded": False,
        "fulltext_available": False,
        "fulltext_path": None,
        "supplements": [],
        "error": None,
    }

    try:
        # Use pmc_id from upstream (step 1) if available, otherwise look it up
        pmc_id = paper.get("pmc_id")
        if pmc_id:
            log.info("PMID %s: using known PMC ID %s", pmid, pmc_id)
        else:
            log.info("Checking PMC availability for PMID %s", pmid)
            pmc_id = check_pmc_availability(pmid, limiter)
        entry["pmc_id"] = pmc_id

        if pmc_id is None:
            log.info("PMID %s: not in PMC OA", pmid)
        else:
            pkg_dir = download_pmc_package(pmc_id, download_dir, limiter)
            if pkg_dir is None:
                log.info("PMID %s (%s): download failed or not available", pmid, pmc_id)
            else:
                entry["downloaded"] = True

                # Find and extract JATS XML
                xml_files = list(pkg_dir.rglob("*.nxml")) + list(pkg_dir.rglob("*.xml"))
                for xf in xml_files:
                    text = extract_text_from_jats(xf)
                    if len(text) > 500:
                        txt_path = paper_dir / "fulltext.txt"
                        txt_path.write_text(text, encoding="utf-8")
                        entry["fulltext_available"] = True
                        entry["fulltext_path"] = str(txt_path)
                        # Download supplements referenced in JATS XML
                        download_supplements_from_xml(xf, pmc_id, pkg_dir, limiter)
                        break

                entry["supplements"] = find_supplements(pkg_dir)

        log.info(
            "PMID %s (%s): downloaded=%s, fulltext=%s, supplements=%d",
            pmid, entry["pmc_id"], entry["downloaded"],
            entry["fulltext_available"], len(entry["supplements"]),
        )
    except Exception as e:
        log.error("PMID %s: step 3 failed: %s", pmid, e)
        entry["error"] = str(e)

    # Save per-paper result
    import json
    result_path = paper_dir / "download.json"
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(entry, f, indent=2, ensure_ascii=False)

    return entry


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run(config: dict, screening_path: Path | None = None) -> Path:
    """Execute step 3: download full texts from PMC OA.

    Args:
        config: Pipeline configuration dict.
        screening_path: Path to step 2 output. Auto-discovered if None.

    Returns:
        Path to the downloads manifest JSONL.
    """
    log.info("Step 3: Full-Text Download")

    # Configure Entrez
    Entrez.email = config.get("entrez", {}).get("email", "researcher@example.com")
    api_key = config.get("entrez", {}).get("api_key")
    if api_key:
        Entrez.api_key = api_key

    rate_limit = config.get("entrez", {}).get("rate_limit", 3)
    limiter = RateLimiter(rate_limit)

    if screening_path is None:
        screening_path = find_latest_output("screening", config.get("output", {}).get("dir", "outputs"))
    if screening_path is None:
        raise FileNotFoundError("No screening file found. Run step 2 first.")

    screening = load_jsonl(screening_path)
    relevant = [r for r in screening if r.get("relevant") is True]
    log.info("Found %d relevant papers from screening", len(relevant))

    manifest = []
    for paper in relevant:
        entry = process_paper(paper, config, limiter)
        manifest.append(entry)

    downloaded = sum(1 for m in manifest if m["downloaded"])
    log.info("Download complete: %d/%d papers downloaded", downloaded, len(manifest))

    output_path = make_output_path("downloads", "jsonl", config)
    save_jsonl(manifest, output_path)
    log.info("Saved download manifest to %s", output_path)

    return output_path


if __name__ == "__main__":
    cfg = load_config()
    run(cfg)
