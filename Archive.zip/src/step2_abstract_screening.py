"""Step 2: Screen paper abstracts for relevance using Gemini CLI.

Reads the papers JSONL from step 1, sends each abstract through Gemini with
the screening prompt, and writes screening decisions.

Output: outputs/screening_YYYYMMDD_HHMM_{hash}.jsonl
"""

import json
from pathlib import Path

from utils import (
    call_gemini,
    find_latest_output,
    load_config,
    load_jsonl,
    make_output_path,
    save_jsonl,
    setup_logging,
)

log = setup_logging("step2")


def _load_prompt_template() -> str:
    """Load the screening prompt template."""
    prompt_path = Path(__file__).parent.parent / "prompts" / "screening_prompt.txt"
    return prompt_path.read_text()


def _format_criteria(items: list[str]) -> str:
    """Format a list of criteria as numbered lines."""
    return "\n".join(f"{i+1}. {c}" for i, c in enumerate(items))


def screen_paper(paper: dict, prompt_template: str, config: dict) -> dict:
    """Screen a single paper for relevance.

    Returns a dict with: pmid, relevant, confidence, reason, criteria_met.
    """
    pmid = paper["pmid"]
    abstract = paper.get("abstract", "")

    if not abstract:
        return {
            "pmid": pmid,
            "relevant": False,
            "confidence": "high",
            "reason": "No abstract available",
            "criteria_met": {},
        }

    screening_cfg = config.get("screening", {})
    inclusion = _format_criteria(screening_cfg.get("inclusion_criteria", []))
    exclusion = _format_criteria(screening_cfg.get("exclusion_criteria", []))

    prompt = prompt_template.format(
        inclusion_criteria=inclusion,
        exclusion_criteria=exclusion,
        title=paper.get("title", ""),
        abstract=abstract,
    )

    timeout = config.get("gemini", {}).get("timeout", 60)
    result = call_gemini(prompt, timeout=timeout)

    if result is None:
        log.warning("Gemini returned no result for PMID %s", pmid)
        return {
            "pmid": pmid,
            "relevant": None,
            "confidence": "error",
            "reason": "Gemini call failed",
            "criteria_met": {},
        }

    result["pmid"] = pmid
    return result


def _load_done_pmids(output_path: Path) -> set[str]:
    """Load PMIDs already screened from a partial output file."""
    if not output_path.exists():
        return set()
    done = set()
    for rec in load_jsonl(output_path):
        if "pmid" in rec:
            done.add(str(rec["pmid"]))
    return done


def run(config: dict, papers_path: Path | None = None) -> Path:
    """Execute step 2: screen abstracts and save decisions.

    Writes results incrementally (one JSONL line per paper) so progress
    survives interruptions. On restart, already-screened PMIDs are skipped.

    Args:
        config: Pipeline configuration dict.
        papers_path: Path to step 1 output. Auto-discovered if None.

    Returns:
        Path to the screening output JSONL.
    """
    log.info("Step 2: Abstract Screening")

    if papers_path is None:
        papers_path = find_latest_output("papers", config.get("output", {}).get("dir", "outputs"))
    if papers_path is None:
        raise FileNotFoundError("No papers file found. Run step 1 first.")

    papers = load_jsonl(papers_path)
    log.info("Loaded %d papers from %s", len(papers), papers_path)

    output_path = make_output_path("screening", "jsonl", config)

    # Check for partial progress from a previous run
    done_pmids = _load_done_pmids(output_path)
    if done_pmids:
        log.info("Resuming: %d papers already screened, skipping them", len(done_pmids))

    prompt_template = _load_prompt_template()

    for i, paper in enumerate(papers, 1):
        pmid = str(paper.get("pmid"))
        if pmid in done_pmids:
            log.info("Skipping %d/%d: PMID %s (already done)", i, len(papers), pmid)
            continue

        log.info("Screening %d/%d: PMID %s", i, len(papers), paper.get("pmid"))
        result = screen_paper(paper, prompt_template, config)
        result["title"] = paper.get("title", "")

        # Append incrementally
        with open(output_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(result, ensure_ascii=False) + "\n")

    results = load_jsonl(output_path)
    relevant = sum(1 for r in results if r.get("relevant") is True)
    log.info("Screening complete: %d/%d papers relevant", relevant, len(results))
    log.info("Results at %s", output_path)

    return output_path


if __name__ == "__main__":
    cfg = load_config()
    run(cfg)
