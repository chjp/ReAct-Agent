"""Step 5: Retrieve BioSample attributes and SRA run IDs from NCBI.

For each BioProject ID found in step 4, fetches all linked BioSamples
(with full attribute metadata) and SRA run accessions.

Output: outputs/ncbi_metadata_YYYYMMDD_HHMM_{hash}.jsonl
"""

import re
import xml.etree.ElementTree as ET
from pathlib import Path

from Bio import Entrez

from utils import (
    RateLimiter,
    find_latest_output,
    load_config,
    load_jsonl,
    make_output_path,
    make_paper_dir,
    save_jsonl,
    setup_logging,
)

log = setup_logging("step5")


# ---------------------------------------------------------------------------
# BioSample retrieval
# ---------------------------------------------------------------------------

def get_biosamples(bioproject_id: str, limiter: RateLimiter) -> list[dict]:
    """Fetch all BioSample records linked to a BioProject.

    Returns a list of dicts with: biosample_id, accession, attributes.
    """
    # Resolve BioProject accession → UID
    limiter.wait()
    handle = Entrez.esearch(db="bioproject", term=bioproject_id)
    search_result = Entrez.read(handle)
    handle.close()

    bp_uids = search_result.get("IdList", [])
    if not bp_uids:
        log.warning("BioProject %s not found in NCBI", bioproject_id)
        return []

    bp_uid = bp_uids[0]

    # BioProject → BioSample link
    limiter.wait()
    handle = Entrez.elink(dbfrom="bioproject", db="biosample", id=bp_uid)
    link_result = Entrez.read(handle)
    handle.close()

    biosample_uids = []
    if link_result and link_result[0].get("LinkSetDb"):
        for link_set in link_result[0]["LinkSetDb"]:
            for link in link_set.get("Link", []):
                biosample_uids.append(link["Id"])

    if not biosample_uids:
        log.info("No BioSamples linked to %s", bioproject_id)
        return []

    log.info("%s: found %d linked BioSamples", bioproject_id, len(biosample_uids))

    # Fetch BioSample XML in batches
    biosamples = []
    batch_size = 100
    for i in range(0, len(biosample_uids), batch_size):
        batch = biosample_uids[i : i + batch_size]
        log.info(
            "  Fetching BioSamples %d-%d of %d",
            i + 1, i + len(batch), len(biosample_uids),
        )
        limiter.wait()
        handle = Entrez.efetch(db="biosample", id=batch, rettype="full", retmode="xml")
        xml_data = handle.read()
        handle.close()

        root = ET.fromstring(xml_data)
        for bs_elem in root.findall(".//BioSample"):
            bs_id_elem = bs_elem.find(".//Id[@db='BioSample']")
            bs_acc_elem = bs_elem.get("accession", "")

            attributes = {}
            for attr in bs_elem.findall(".//Attribute"):
                attr_name = attr.get("attribute_name", attr.get("harmonized_name", "unknown"))
                attr_value = attr.text.strip() if attr.text else ""
                attributes[attr_name] = attr_value

            biosamples.append({
                "biosample_id": bs_id_elem.text if bs_id_elem is not None else None,
                "accession": bs_acc_elem,
                "attributes": attributes,
            })

    return biosamples


# ---------------------------------------------------------------------------
# SRA run retrieval
# ---------------------------------------------------------------------------

def get_sra_runs(bioproject_id: str, limiter: RateLimiter) -> list[dict]:
    """Fetch all SRA run records linked to a BioProject.

    Returns a list of dicts with: run_accession, biosample_accession,
    experiment_accession, platform, library_strategy.
    """
    limiter.wait()
    handle = Entrez.esearch(db="sra", term=bioproject_id, retmax=10000)
    search_result = Entrez.read(handle)
    handle.close()

    sra_uids = search_result.get("IdList", [])
    if not sra_uids:
        log.info("No SRA records found for %s", bioproject_id)
        return []

    log.info("%s: found %d SRA records", bioproject_id, len(sra_uids))

    runs = []
    batch_size = 100
    for i in range(0, len(sra_uids), batch_size):
        batch = sra_uids[i : i + batch_size]
        limiter.wait()
        handle = Entrez.efetch(db="sra", id=batch, rettype="full", retmode="xml")
        xml_data = handle.read()
        handle.close()

        if isinstance(xml_data, bytes):
            xml_data = xml_data.decode("utf-8")

        # Parse SRA XML — each EXPERIMENT_PACKAGE contains run info
        try:
            root = ET.fromstring(f"<root>{xml_data}</root>")
        except ET.ParseError:
            # Try wrapping in root element if needed
            try:
                root = ET.fromstring(xml_data)
            except ET.ParseError as e:
                log.warning("Failed to parse SRA XML for %s: %s", bioproject_id, e)
                continue

        for pkg in root.iter("EXPERIMENT_PACKAGE"):
            exp_elem = pkg.find(".//EXPERIMENT")
            exp_acc = exp_elem.get("accession", "") if exp_elem is not None else ""

            # Platform
            platform = ""
            platform_elem = pkg.find(".//PLATFORM")
            if platform_elem is not None and len(platform_elem) > 0:
                platform = platform_elem[0].tag  # e.g., ILLUMINA

            # Library strategy
            lib_strategy = ""
            lib_elem = pkg.find(".//LIBRARY_STRATEGY")
            if lib_elem is not None and lib_elem.text:
                lib_strategy = lib_elem.text

            # BioSample accession
            biosample_acc = ""
            for ext_id in pkg.iter("EXTERNAL_ID"):
                if ext_id.get("namespace") == "BioSample":
                    biosample_acc = ext_id.text or ""
                    break
            # Also check sample attributes
            if not biosample_acc:
                sample_elem = pkg.find(".//SAMPLE")
                if sample_elem is not None:
                    biosample_acc = sample_elem.get("accession", "")

            # Run accessions
            for run_elem in pkg.iter("RUN"):
                run_acc = run_elem.get("accession", "")
                if run_acc:
                    runs.append({
                        "run_accession": run_acc,
                        "biosample_accession": biosample_acc,
                        "experiment_accession": exp_acc,
                        "platform": platform,
                        "library_strategy": lib_strategy,
                    })

    return runs


# ---------------------------------------------------------------------------
# Per-paper processing
# ---------------------------------------------------------------------------

def process_paper(parsed_record: dict, config: dict, limiter: RateLimiter) -> dict:
    """Retrieve NCBI metadata for a single paper's BioProject IDs.

    Args:
        parsed_record: A single step 4 output dict (with pmid, bioproject_ids).
        config: Pipeline configuration dict.
        limiter: Shared RateLimiter instance.

    Returns:
        Per-paper NCBI record:
        ``{"pmid", "bioprojects": [{bioproject_id, biosamples, sra_runs}],
           "total_biosamples", "total_sra_runs", "error"}``
    """
    pmid = parsed_record["pmid"]
    paper_dir = make_paper_dir(pmid, config)
    bp_ids = parsed_record.get("bioproject_ids", [])

    result = {
        "pmid": pmid,
        "bioprojects": [],
        "total_biosamples": 0,
        "total_sra_runs": 0,
        "error": None,
    }

    try:
        for bp_id in bp_ids:
            log.info("PMID %s: retrieving metadata for %s", pmid, bp_id)
            biosamples = get_biosamples(bp_id, limiter)
            sra_runs = get_sra_runs(bp_id, limiter)

            result["bioprojects"].append({
                "bioproject_id": bp_id,
                "biosample_count": len(biosamples),
                "biosamples": biosamples,
                "sra_run_count": len(sra_runs),
                "sra_runs": sra_runs,
            })

            log.info("  %s: %d BioSamples, %d SRA runs", bp_id, len(biosamples), len(sra_runs))

        result["total_biosamples"] = sum(bp["biosample_count"] for bp in result["bioprojects"])
        result["total_sra_runs"] = sum(bp["sra_run_count"] for bp in result["bioprojects"])
    except Exception as e:
        log.error("PMID %s: step 5 failed: %s", pmid, e)
        result["error"] = str(e)

    # Save per-paper result
    import json
    result_path = paper_dir / "ncbi_metadata.json"
    with open(result_path, "w", encoding="utf-8") as f:
        json.dump(result, f, indent=2, ensure_ascii=False)

    return result


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def run(config: dict, parsed_path: Path | None = None) -> Path:
    """Execute step 5: retrieve NCBI metadata for all BioProjects.

    Args:
        config: Pipeline configuration dict.
        parsed_path: Path to step 4 output. Auto-discovered if None.

    Returns:
        Path to the NCBI metadata output JSONL.
    """
    log.info("Step 5: NCBI Retrieval")

    Entrez.email = config.get("entrez", {}).get("email", "researcher@example.com")
    api_key = config.get("entrez", {}).get("api_key")
    if api_key:
        Entrez.api_key = api_key

    rate_limit = config.get("entrez", {}).get("rate_limit", 3)
    limiter = RateLimiter(rate_limit)

    if parsed_path is None:
        parsed_path = find_latest_output("parsed", config.get("output", {}).get("dir", "outputs"))
    if parsed_path is None:
        raise FileNotFoundError("No parsed file found. Run step 4 first.")

    parsed_records = load_jsonl(parsed_path)

    # Use per-paper processing, then flatten to BioProject-centric JSONL for backward compat
    ncbi_records = []
    seen_bioprojects = set()
    for rec in parsed_records:
        paper_result = process_paper(rec, config, limiter)
        for bp in paper_result["bioprojects"]:
            bp_id = bp["bioproject_id"]
            if bp_id not in seen_bioprojects:
                seen_bioprojects.add(bp_id)
                # Flatten to legacy format: one record per BioProject
                ncbi_records.append({
                    "bioproject_id": bp_id,
                    "pmids": [rec["pmid"]],
                    "biosample_count": bp["biosample_count"],
                    "biosamples": bp["biosamples"],
                    "sra_run_count": bp["sra_run_count"],
                    "sra_runs": bp["sra_runs"],
                })
            else:
                # Append PMID to existing record
                for existing in ncbi_records:
                    if existing["bioproject_id"] == bp_id:
                        if rec["pmid"] not in existing["pmids"]:
                            existing["pmids"].append(rec["pmid"])
                        break

    total_samples = sum(r["biosample_count"] for r in ncbi_records)
    total_runs = sum(r["sra_run_count"] for r in ncbi_records)
    log.info("NCBI retrieval complete: %d BioSamples, %d SRA runs total", total_samples, total_runs)

    output_path = make_output_path("ncbi_metadata", "jsonl", config)
    save_jsonl(ncbi_records, output_path)
    log.info("Saved NCBI metadata to %s", output_path)

    return output_path


if __name__ == "__main__":
    cfg = load_config()
    run(cfg)
